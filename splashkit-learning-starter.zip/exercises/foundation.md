# Exercises: Foundation

1. **Draw & Clear:** Change clear color every second.
2. **HUD:** Show FPS, mouse (x,y), key pressed.
3. **Mover:** WASD move a square; keep inside window.
4. **Collector:** Spawn 5 coins; collect to increase score.
5. **Sound-on-hit:** Play sound when colliding with obstacle.
