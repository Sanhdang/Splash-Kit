# 05 — Sound & Music

- Load `SoundEffect` and `Music`.
- Play on events (jump, hit, collect).
- Loop background music, pause/resume.

**Exercise:** Add volume slider by +/- keys.
