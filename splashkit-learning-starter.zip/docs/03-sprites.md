# 03 — Sprites & Bitmaps

- Load a bitmap, create a sprite, set velocity.
- Wrap around window edges.
- Simple parallax background with two bitmaps.

**Exercise:** Spawn stars at random and scroll them downward.
