# 01 — Setup & Your First Window

This lesson gets you drawing **something on screen** in a SplashKit window and closing it safely.

## Goals
- Create a window and a game loop
- Clear the screen, draw text, and handle ESC to quit

## Code
See `src/HelloSplashKit/Program.cs`.

## Try this
- Change background color every second.
- Draw your name at the mouse position.
- Map WASD to move a rectangle.

## Teach It Forward
Record a 30s screen capture showing your result and post one tip that helped you.
