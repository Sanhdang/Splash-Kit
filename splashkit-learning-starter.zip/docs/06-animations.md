# 06 — Sprite Sheet Animations

- Set cell details on a bitmap
- Create `AnimationScript` and `Animation`
- Switch animations on input (idle/run/jump)

**Exercise:** Add a jump animation on SPACE.
