# 04 — Collisions

- Axis-aligned bounding box vs pixel-perfect collision
- Hit flash effect and invulnerability timer

**Exercise:** Make coins you can collect and keep score.
