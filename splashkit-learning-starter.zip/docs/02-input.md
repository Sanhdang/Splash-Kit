# 02 — Keyboard & Mouse Input

- Check key pressed this frame vs held.
- Read mouse position and clicks.
- Show an on-screen HUD of current inputs.

**Exercise:** Build a tiny "etch-a-sketch": hold left mouse to draw points.
