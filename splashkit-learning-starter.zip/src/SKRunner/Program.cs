using System;
using System.Collections.Generic;
using SplashKitSDK;

public class Player
{
    public Sprite Sprite;
    public float Speed = 4f;

    public Player(Bitmap bmp)
    {
        Sprite = SplashKit.CreateSprite(bmp);
        SplashKit.SpriteSetX(Sprite, 80);
        SplashKit.SpriteSetY(Sprite, 360);
    }

    public void Update()
    {
        float dx = 0, dy = 0;
        if (SplashKit.KeyDown(KeyCode.WKey)) dy -= Speed;
        if (SplashKit.KeyDown(KeyCode.SKey)) dy += Speed;
        if (SplashKit.KeyDown(KeyCode.AKey)) dx -= Speed;
        if (SplashKit.KeyDown(KeyCode.DKey)) dx += Speed;
        SplashKit.SpriteSetX(Sprite, SplashKit.SpriteX(Sprite) + dx);
        SplashKit.SpriteSetY(Sprite, SplashKit.SpriteY(Sprite) + dy);
    }

    public void Draw() => SplashKit.DrawSprite(Sprite);
}

public class Obstacle
{
    public Sprite Sprite;
    public Obstacle(Bitmap bmp, float x, float y, float vx)
    {
        Sprite = SplashKit.CreateSprite(bmp);
        SplashKit.SpriteSetX(Sprite, x);
        SplashKit.SpriteSetY(Sprite, y);
        SplashKit.SpriteSetDx(Sprite, vx);
    }
    public void Update()
    {
        SplashKit.UpdateSprite(Sprite);
        if (SplashKit.SpriteX(Sprite) < -100) SplashKit.SpriteSetX(Sprite, 900);
    }
    public void Draw() => SplashKit.DrawSprite(Sprite);
}

public static class SKRunner
{
    public static void Main()
    {
        const int W = 900, H = 500;
        Window w = new Window("SKRunner (mini)", W, H);

        // Assets (replace with your own PNGs in the working directory)
        Bitmap playerBmp = SplashKit.LoadBitmap("player", "player.png");
        Bitmap obstacleBmp = SplashKit.LoadBitmap("ob", "obstacle.png");
        SoundEffect pickup = SplashKit.LoadSoundEffect("pickup", "pickup.wav");

        Player player = new Player(playerBmp);

        List<Obstacle> obs = new List<Obstacle>();
        for (int i = 0; i < 4; i++)
            obs.Add(new Obstacle(obstacleBmp, 300 + i * 180, 380, -3f - i));

        int score = 0;
        Font font = SplashKit.LoadFont("default", "arial.ttf");
        Music music = SplashKit.LoadMusic("bgm", "music.mp3");

        SplashKit.PlayMusic(music, 0.5f);

        while (!SplashKit.WindowCloseRequested(w))
        {
            SplashKit.ProcessEvents();
            if (SplashKit.KeyTyped(KeyCode.EscapeKey)) break;

            player.Update();
            foreach (var o in obs) o.Update();

            // Collision check
            foreach (var o in obs)
            {
                if (SplashKit.SpriteCollision(player.Sprite, o.Sprite))
                {
                    score += 1;
                    SplashKit.PlaySoundEffect(pickup);
                    // Move obstacle back to right
                    SplashKit.SpriteSetX(o.Sprite, 900 + SplashKit.Rnd() * 300);
                }
            }

            SplashKit.ClearScreen(Color.Black);

            // Parallax background (two rectangles for demo)
            SplashKit.FillRectangle(Color.DarkSlateGray, 0, 0, W, H);
            SplashKit.FillRectangle(Color.Gray, 0, 420, W, 80);

            player.Draw();
            foreach (var o in obs) o.Draw();

            SplashKit.DrawText($"Score: {score}", Color.White, font, 20, 20, 20);

            SplashKit.RefreshScreen(60);
        }

        SplashKit.FreeAll();
        w.Close();
    }
}
