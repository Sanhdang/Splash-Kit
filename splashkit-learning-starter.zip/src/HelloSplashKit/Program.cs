using System;
using SplashKitSDK;

public static class Program
{
    public static void Main()
    {
        const int W = 800, H = 500;
        Window w = new Window("Hello SplashKit", W, H);

        // Main loop
        while (!SplashKit.WindowCloseRequested(w))
        {
            SplashKit.ProcessEvents();

            // Logic: quit on ESC
            if (SplashKit.KeyTyped(KeyCode.EscapeKey)) break;

            // Draw
            SplashKit.ClearScreen(Color.Black);
            SplashKit.DrawText("Hello SplashKit! Press ESC to quit.", Color.White, 20, 20);

            // Draw a moving circle following the mouse
            float mx = SplashKit.MouseX();
            float my = SplashKit.MouseY();
            SplashKit.FillCircle(Color.White, mx, my, 8);

            SplashKit.RefreshScreen(60);
        }

        w.Close();
    }
}
