---
name: New lesson idea
about: Propose a new concept, demo, or exercise
title: "[Lesson] "
labels: enhancement, docs
assignees: ""
---

## Problem / concept to teach
<!-- e.g., "Sprite sheet animations" -->

## Why it's helpful
<!-- Clear benefit for beginners -->

## Minimal demo outline
- [ ] Goal
- [ ] Steps
- [ ] Code snippet(s)
- [ ] Exercise
- [ ] Teach It Forward prompt
